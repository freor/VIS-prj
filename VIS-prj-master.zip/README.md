# VIS-prj

- data: youtube-data

- thumbnail_img: *top-100* thumbnail images

- youtube-json: preprocessed json file

- utils: json generator & image downloader

- node-edge-graph: d3 grpah code

- thumbnail_net: thumbnail analysis code using pretrained resnet
